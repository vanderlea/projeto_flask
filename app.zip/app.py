import os

from flask import Flask, render_template, request
from dao.aluno_dao import AlunoDAO
from dao.professor_dao import ProfessorDAO
from dao.turma_dao import TurmaDAO
from dao.curso_dao import CursoDAO
import psycopg2

DATABASE_URL = "postgresql://neondb_owner:npg_eTgiMwpX5Yx3@ep-proud-glitter-b7sfoqm1-pooler.c-13.us-east-1.aws.neon.tech/neondb?channel_binding=require&sslmode=require"


conn = psycopg2.connect(DATABASE_URL)
cursor = conn.cursor()







app = Flask(__name__)



@app.route('/')
def home():
    return render_template('dashboard/index.html')

@app.route('/sobre')
def sobre_o_sistema():
    return render_template('dashboard/sobre.html')

@app.route('/contato')
def contato():
    return render_template('dashboard/contato.html')

@app.route('/aluno')
def lista():
    dao = AlunoDAO()
    lista = dao.listar()
    return render_template('aluno/lista.html', lista=lista)
    

@app.route('/professor')
def listar_professor():
    dao = ProfessorDAO()
    lista = dao.listar()
    return render_template('professor/lista.html', lista=lista)

@app.route('/professor/editar/<int:id>')
def editar_professor(id):
    return f"Página de edição do professor com ID: {id}"

@app.route('/professor/excluir/<int:id>')
def excluir_professor(id):

      return f"Excluindo professor com ID: {id}"

@app.route('/turma')
def listar_turma():
    dao = TurmaDAO()
    lista = dao.listar()
    return render_template('turma/lista.html', lista=lista)

@app.route('/curso')
def listar_curso():
    dao = CursoDAO()
    lista = dao.listar()
    return render_template('curso/lista.html', lista=lista)

@app.route('/login', methods=['POST'])
def login():
    usuario = request.form['usuario']
    senha = request.form['senha']
    email = request.form['email']
    dados= f'Usuário: {usuario}, Senha: {senha}, Email: {email}'
    return render_template('saudacao/saudacao.html', valor_recebido=dados)

@app.route('/saudacao/<nome>')
def saudacao(nome):
    return render_template('saudacao/saudacao.html', valor_recebido=nome)


@app.route('/ajuda')
def ajuda():
    
    return render_template('ajuda/ajuda.html')

if __name__ == '__main__':
    app.run(debug=True)






    #Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser